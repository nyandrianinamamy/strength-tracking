import Foundation
import HealthKit
import WatchConnectivity
import Flutter

class WatchSessionManager: NSObject, WCSessionDelegate, FlutterStreamHandler {

    static let shared = WatchSessionManager()

    private var session: WCSession?
    private var methodChannel: FlutterMethodChannel?
    private var eventSink: FlutterEventSink?
    private var pendingEvents: [[String: Any]] = []
    private let healthStore = HKHealthStore()
    /// Tracks which session we already launched the watch app for,
    /// so we only trigger once per workout.
    private var lastLaunchedSessionId: String?

    private override init() {
        super.init()
    }

    // MARK: - Setup

    func activateSession() {
        guard WCSession.isSupported() else { return }
        let wcSession = WCSession.default
        wcSession.delegate = self
        wcSession.activate()
        session = wcSession
    }

    func configure(with controller: FlutterViewController) {
        // Method channel for Dart → iOS
        methodChannel = FlutterMethodChannel(
            name: "com.strengthapp/watch",
            binaryMessenger: controller.binaryMessenger
        )
        methodChannel?.setMethodCallHandler(handleMethodCall)

        // Event channel for iOS → Dart (Watch messages)
        let eventChannel = FlutterEventChannel(
            name: "com.strengthapp/watch_events",
            binaryMessenger: controller.binaryMessenger
        )
        eventChannel.setStreamHandler(self)

        activateSession()
    }

    // MARK: - Flutter → Watch (MethodChannel handler)

    private func handleMethodCall(call: FlutterMethodCall, result: @escaping FlutterResult) {
        switch call.method {
        case "sendSessionUpdate":
            guard let args = call.arguments as? [String: Any] else {
                result(FlutterError(code: "INVALID_ARGS", message: "Expected dictionary", details: nil))
                return
            }
            launchWatchAppIfNeeded(args)
            sendToWatch(args)
            result(nil)

        case "sendSessionEnd":
            lastLaunchedSessionId = nil
            sendToWatch(["type": "session_end"])
            result(nil)

        case "isWatchPaired":
            result(session?.isPaired ?? false)

        case "isWatchReachable":
            result(session?.isReachable ?? false)

        default:
            result(FlutterMethodNotImplemented)
        }
    }

    // MARK: - Auto-launch Watch App

    /// Launches the watch companion app via HealthKit when a new workout session
    /// starts and the watch is paired. Only triggers once per session.
    private func launchWatchAppIfNeeded(_ message: [String: Any]) {
        guard let sessionData = message["session"] as? [String: Any],
              let sessionId = sessionData["sessionId"] as? String,
              sessionId != lastLaunchedSessionId,
              let wcSession = session, wcSession.isPaired,
              HKHealthStore.isHealthDataAvailable() else { return }

        lastLaunchedSessionId = sessionId

        let workoutType = HKObjectType.workoutType()
        healthStore.requestAuthorization(toShare: [workoutType], read: [workoutType]) { [weak self] authorized, error in
            guard let self = self else { return }
            if let error = error {
                print("HealthKit authorization error: \(error)")
                return
            }
            guard authorized else {
                print("HealthKit workout authorization denied")
                return
            }

            let config = HKWorkoutConfiguration()
            config.activityType = .traditionalStrengthTraining
            config.locationType = .indoor

            self.healthStore.startWatchApp(with: config) { success, error in
                if let error = error {
                    print("Failed to launch watch app: \(error)")
                } else {
                    print("Watch app launch requested: \(success)")
                }
            }
        }
    }

    // MARK: - Send to Watch

    private func sendToWatch(_ message: [String: Any]) {
        guard let session = session, session.isPaired else { return }

        let isSessionEnd = (message["type"] as? String) == "session_end"

        // Try direct message if reachable
        if session.isReachable {
            session.sendMessage(message, replyHandler: nil) { error in
                print("Direct send to Watch failed: \(error), using fallback")
                if isSessionEnd {
                    session.transferUserInfo(message)
                } else {
                    try? session.updateApplicationContext(message)
                }
            }
        } else if isSessionEnd {
            // session_end must be delivered reliably
            session.transferUserInfo(message)
        } else {
            do {
                try session.updateApplicationContext(message)
            } catch {
                print("Failed to update application context: \(error)")
            }
        }

        // Always send session_end via transferUserInfo as backup
        if isSessionEnd {
            session.transferUserInfo(message)
        }
    }

    // MARK: - WCSessionDelegate

    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        print("WCSession activated: \(activationState.rawValue), error: \(String(describing: error))")
    }

    func sessionDidBecomeInactive(_ session: WCSession) {}

    func sessionDidDeactivate(_ session: WCSession) {
        // Reactivate
        session.activate()
    }

    // Receive direct message from Watch
    func session(_ session: WCSession, didReceiveMessage message: [String: Any]) {
        handleWatchMessage(message)
    }

    func session(_ session: WCSession, didReceiveMessage message: [String: Any], replyHandler: @escaping ([String: Any]) -> Void) {
        handleWatchMessage(message)
        replyHandler(["status": "ok"])
    }

    // Receive guaranteed delivery from Watch (transferUserInfo)
    func session(_ session: WCSession, didReceiveUserInfo userInfo: [String: Any]) {
        handleWatchMessage(userInfo)
    }

    private func handleWatchMessage(_ message: [String: Any]) {
        guard let type = message["type"] as? String else { return }

        let forwardedMessage: [String: Any]
        switch type {
        case "log_set", "log_timed_set":
            forwardedMessage = message

        case "request_sync":
            forwardedMessage = ["type": "request_sync"]

        default:
            return
        }

        DispatchQueue.main.async {
            if let sink = self.eventSink {
                sink(forwardedMessage)
            } else {
                self.pendingEvents.append(forwardedMessage)
            }
        }
    }

    // MARK: - FlutterStreamHandler

    func onListen(withArguments arguments: Any?, eventSink events: @escaping FlutterEventSink) -> FlutterError? {
        eventSink = events
        let bufferedEvents = pendingEvents
        pendingEvents.removeAll()
        for event in bufferedEvents {
            events(event)
        }
        return nil
    }

    func onCancel(withArguments arguments: Any?) -> FlutterError? {
        eventSink = nil
        return nil
    }
}
